/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cgetertftp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author root
 */
public class FileManager {
    public static BufferedReader myReader(File in) throws IOException{
        FileInputStream fis = new FileInputStream(in);
        InputStreamReader reader = new InputStreamReader(fis);
        fis.getChannel().position(0);
        return new BufferedReader(reader);     
    }
    
    public static int lineCounter(File in) throws IOException{
        int count = 0;
        BufferedReader reader = FileManager.myReader(in);
        while(reader.readLine() != null){
            count++;
        }
        return count;
    }
}
