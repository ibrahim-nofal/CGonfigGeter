/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cgetertftp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.net.tftp.TFTPClient;

/**
 *
 * @author root
 */
public class MacDownloader {

    File ipFile = null;
    File macFile = null;
    static int ThreadNumber = 500;
    int MainPort = 69;
    TFTPClient tftp = null;
    FileOutputStream out = null;
    ArrayList<Thread> threads = new ArrayList<>();

    public MacDownloader(TFTPClient tftp) {
        this.tftp = tftp;
    }

    public void setIpFile(File ipFile) {
        this.ipFile = ipFile;
    }

    public void setMacFile(File macFile) {
        this.macFile = macFile;
    }

    public File getIpFile() {
        return this.ipFile;
    }

    public File getMacFile() {
        return this.macFile;
    }

    public boolean connect() {
        try {
            tftp.open();
            return true;
        } catch (SocketException ex) {
            Logger.getLogger(MacDownloader.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean recive(String fName, InetAddress addr) {
        try {
                File result = new File("result/" + addr.getHostName() + "_" + fName);
                out = new FileOutputStream(result);
                if (tftp.receiveFile(fName, TFTPClient.ASCII_MODE, out, addr, this.MainPort) >= 1) {
                    return true;
                } else {                 
                    result.delete();
                    return false;
                }
        } catch (IOException ex) {
            Logger.getLogger(MacDownloader.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
