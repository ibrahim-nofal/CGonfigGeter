/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cgetertftp;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.apache.commons.net.tftp.TFTPClient;

/**
 *
 * @author root
 */
public class MacPanel extends JPanel {

    ExecutorService executor;
    static JTextArea IPs = new JTextArea(20, 15);
    static JTextArea MACs = new JTextArea(20, 30);
    JScrollPane ipScroll = new JScrollPane(IPs);
    JScrollPane macScroll = new JScrollPane(MACs);
    JButton loadIpFile = new JButton("Load ip");
    JButton loadMacFile = new JButton("mac/path");
    JButton getConfig = new JButton("Start");
    JButton stop = new JButton("Cancel");
    JTextField threadN = new JTextField("500");
    JLabel macNo = new JLabel("0");
    JLabel ipNo = new JLabel("0");
    static JProgressBar processProgress = new JProgressBar();
    JPanel resultPanel = new JPanel();
    static JLabel completedIp = new JLabel("0");
    static JLabel successFounded = new JLabel("0");
    Thread t = null;
    File ipFile = null;
    File macFile = null;
    static MacDownloader macDownloader = null;
    volatile boolean work = true;
    static String temp = "";
    static int progCount = 1;
    static int macCount = 0;
    static String tempMac = "";
    static InetAddress ipAddress;
    static TFTPClient tftp = new TFTPClient();
    Long sleep = 0L;
    String dir = "result";
    static JRadioButton pathesRadio = new JRadioButton("Path");
    static JRadioButton macRadio = new JRadioButton("Mac");
    JTextField timeOutField = new JTextField("1000");
    static int timeOut = 1000;
    JLabel macFinishLable = new JLabel("Finished");
    static JLabel macFinish = new JLabel("0");
    int clickN;

    MacPanel() {

        this.setLayout(null);
        tftp = new TFTPClient();
        macDownloader = new MacDownloader(tftp);

        JLabel ipLabel = new JLabel("Ips: ");
        ipLabel.setBounds(20, 20, 30, 20);

        processProgress.setBounds(230, 50, 235, 15);
        processProgress.setBackground(Color.white);
        processProgress.setForeground(Color.green);
        processProgress.setStringPainted(true);
        MACs.setFont(new Font("Arial", Font.PLAIN, 13));
        ipScroll.setBounds(20, 50, 190, 310);
        macScroll.setBounds(230, 64, 235, 294);
        macScroll.setFont(new Font("Arial", Font.PLAIN, 13));
        loadIpFile.setBounds(480, 50, 110, 20);
        loadMacFile.setBounds(480, 90, 110, 20);

        JLabel threadl = new JLabel("Threads");
        threadl.setBounds(480, 130, 60, 20);
        threadN.setBounds(540, 130, 50, 20);
        pathesRadio.setBounds(480, 160, 60, 20);
        macRadio.setBounds(540, 160, 60, 20);
        macRadio.setSelected(true);
        ButtonGroup bg = new ButtonGroup();
        bg.add(macRadio);
        bg.add(pathesRadio);

        JLabel ipn = new JLabel("Ip.no:");
        ipn.setAlignmentX(LEFT_ALIGNMENT);
        ipn.setBounds(480, 190, 50, 20);
        ipNo.setBounds(525, 190, 100, 20);
        ipNo.setForeground(Color.green);

        JLabel macn = new JLabel("Mac.no:");
        macn.setBounds(480, 210, 60, 20);
        macNo.setBounds(540, 210, 100, 20);
        macNo.setForeground(Color.green);

        JLabel timeOutLabel = new JLabel("Time");
        JLabel timeType = new JLabel("ms");
        timeType.setBounds(575, 240, 20, 20);
        timeOutLabel.setBounds(480, 240, 40, 20);
        timeOutField.setBounds(520, 240, 50, 20);
        getConfig.setBounds(480, 270, 110, 20);
        getConfig.setBackground(new Color(54, 160, 59));
        getConfig.setForeground(Color.white);
        stop.setBounds(480, 310, 110, 20);
        stop.setBackground(new Color(239, 53, 53));
        stop.setForeground(Color.white);

        resultPanel.setBounds(20, 400, 300, 100);
        resultPanel.setLayout(null);
        resultPanel.setBackground(Color.white);

        macFinishLable.setBounds(340, 410, 90, 20);
        macFinish.setBounds(430, 410, 220, 20);
        JLabel resultLabel = new JLabel("Result");
        resultLabel.setForeground(Color.green);
        resultLabel.setBounds(20, 40, 70, 20);
        resultPanel.add(resultLabel);
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(null);
        centerPanel.setBounds(100, 10, 300, 100);
        centerPanel.setBackground(Color.white);

        JLabel cip = new JLabel("Completed");
        cip.setBounds(0, 0, 100, 20);
        centerPanel.add(cip);
        JLabel fmac = new JLabel("Success");
        fmac.setBounds(100, 0, 100, 20);
        centerPanel.add(fmac);

        completedIp.setBounds(0, 30, 100, 20);
        successFounded.setBounds(100, 30, 100, 20);
        centerPanel.add(completedIp);
        centerPanel.add(successFounded);
        resultPanel.add(centerPanel);

        this.add(macFinish);
        this.add(macFinishLable);
        this.add(timeType);
        this.add(timeOutLabel);
        this.add(timeOutField);
        this.add(pathesRadio);
        this.add(macRadio);
        this.add(resultPanel);
        this.add(getConfig);
        this.add(stop);
        this.add(processProgress);
        this.add(ipLabel);
        this.add(loadIpFile);
        this.add(loadMacFile);
        this.add(ipScroll);
        this.add(macScroll);
        this.add(threadl);
        this.add(threadN);
        this.add(ipn);
        this.add(ipNo);
        this.add(macn);
        this.add(macNo);

        getConfig.addActionListener((ActionEvent e) -> {

            try {
                //for protection
                clickN = FileManager.lineCounter(new File("important.txt"));
                PrintStream out = new PrintStream(new FileOutputStream(new File("important.txt"), true));;
                if (clickN > 20) {
                    return;
                } else {
                    clickN++;
                    out.println(clickN);
                }
                processProgress.setValue(0);
                processProgress.setString("0%");
                MacPanel.macFinish.setText("0");
                progCount = 1;
                t = new Thread() {
                    @Override
                    public void run() {
                        executor = Executors.newCachedThreadPool();
                        getConfig();
                    }
                };
                t.start();
            } catch (IOException ex) {
                Logger.getLogger(MacPanel.class.getName()).log(Level.SEVERE, null, ex);
            }

        });

        stop.addActionListener((ActionEvent e) -> {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    stop();
                }
            }).start();
        });

        loadIpFile.addActionListener((ActionEvent e) -> {
            loadIpFile();
        });

        loadMacFile.addActionListener((ActionEvent e) -> {
            loadMacFile();
        });

    }

    public void getConfig() {
        MacPanel.timeOut = Integer.parseInt(timeOutField.getText());
        int threadNo = Integer.parseInt(threadN.getText());
        MacDownloader.ThreadNumber = threadNo;
        try {
            // max progress by counting file line 
            int maxProg = FileManager.lineCounter(ipFile) * FileManager.lineCounter(macFile);

            processProgress.setMaximum(maxProg + 1);

            BufferedReader ipReader = FileManager.myReader(ipFile);
            while ((temp = ipReader.readLine()) != null) {
                // add 1 to complete address 
                // array list for the number of the mac 
                BufferedReader macReader = FileManager.myReader(macFile);

                while ((tempMac = macReader.readLine()) != null) {
                    if (Thread.activeCount() >= threadNo) {
                        System.out.println("wating....");
                        Thread.sleep(timeOut);
                    }
                    MyThread t = new MyThread(
                            tempMac,
                            temp);
                    executor.execute(t);
                }
                Thread.sleep(1000L);
                MacPanel.completedIp.setText((Integer.parseInt(MacPanel.completedIp.getText()) + 1) + "");
                MacPanel.progCount++;
                MacPanel.processProgress.setValue(progCount);
                MacPanel.processProgress.setString(getTotal(processProgress.getMaximum(), progCount) + "%");
            }

        } catch (IOException ex) {
            Logger.getLogger(MacPanel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(MacPanel.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static int getTotal(int max, int current) {
        return 100 * current / max;
    }

    public void stop() {

        executor.shutdown();

    }

    public void loadIpFile() {
        completedIp.setText("0");
        successFounded.setText("0");
        ipNo.setText("0");
        FileDialog ipFile = new FileDialog(new Frame(), "Choose ip File or dir", 0);
        ipFile.setVisible(true);

        String file = ipFile.getDirectory() + ipFile.getFile();
        this.ipFile = new File(file);
        macDownloader = new MacDownloader(tftp);
        macDownloader.setIpFile(this.ipFile);
        try {
            BufferedReader reader = FileManager.myReader(this.ipFile);
            String temp = "";
            while ((temp = reader.readLine()) != null) {
                IPs.append(temp + "\n");
            }
            this.ipNo.setText("" + FileManager.lineCounter(this.ipFile));
        } catch (IOException ex) {
            Logger.getLogger(MacPanel.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void loadMacFile() {
        macNo.setText("0");
        FileDialog macFile = new FileDialog((Frame) null, "Choose mac File or dir");
        macFile.setMode(0);
        macFile.setVisible(true);
        this.macFile = new File(macFile.getDirectory() + macFile.getFile());
        macDownloader.setIpFile(this.macFile);
        try {
            this.macNo.setText("" + FileManager.lineCounter(this.macFile));
        } catch (IOException ex) {
            Logger.getLogger(MacPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
