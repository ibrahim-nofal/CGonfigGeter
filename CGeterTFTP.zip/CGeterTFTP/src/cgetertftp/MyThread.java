/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cgetertftp;

import static cgetertftp.MacPanel.progCount;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.tftp.TFTPClient;

/**
 *
 * @author root
 */
public class MyThread extends Thread {

    public String myMac;
    private String addr = null;
    private String dir = "result";
    private String ds = "/";

    public MyThread(
            String myMac,
            String addr) {
        this.myMac = myMac;
        this.addr = addr;
    }

    public void setMyMac(String a) {
        this.myMac = a;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    @Override
    public void run() {
        MacPanel.macFinish.setText(Integer.parseInt(MacPanel.macFinish.getText()) + 1 + "");
        if (MacPanel.pathesRadio.isSelected()) {
            this.dir = "path";
        } else {
            this.dir = "result";
        }
        TFTPClient tftp = new TFTPClient();
        tftp.setMaxTimeouts(MacPanel.timeOut);
        try {
            InetAddress inet = InetAddress.getByName(addr);
            if (!tftp.isOpen()) {
                tftp.open();
            }
        } catch (SocketException ex) {
            MacPanel.MACs.append("Server Down: " + addr + "\n");
            MacPanel.MACs.setCaretPosition(MacPanel.MACs.getDocument().getLength());
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
            return;
        } catch (UnknownHostException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        String fileMac = myMac;
        if (hasChar('/', fileMac)) {
            fileMac = fileMac.replace("/", "_");
        }
        
        try {
            ByteArrayOutputStream  baos = new ByteArrayOutputStream();
            if (tftp.receiveFile(myMac, TFTPClient.ASCII_MODE, baos , addr, 69) >= 1) {
                MacPanel.successFounded.setText((Integer.parseInt(MacPanel.successFounded.getText()) + 1) + "");
                MacPanel.MACs.append("<<<" + addr + "_" + myMac + ">>>\n");
                try {
                    MacPanel.MACs.setCaretPosition(MacPanel.MACs.getDocument().getLength());
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                if (dir.equals("result")) {
                    File res = new File("result" + ds + addr + "_" + myMac);
                    baos.writeTo(new FileOutputStream(res));
                    fileToServer(res , myMac);
                    Thread.sleep(10L);
                } else {
                    System.out.println(fileMac);
                    File path = new File("path" + ds + addr + "_" + fileMac);
                    baos.writeTo(new FileOutputStream(path));
                }
                
            } else {
                MacPanel.MACs.append(addr + "_" + myMac + "\n");
                MacPanel.MACs.setCaretPosition(MacPanel.MACs.getDocument().getLength());
            }
        } catch (IOException ex) {
            //file.delete();
            MacPanel.MACs.append(addr + "_" + myMac + "\n");
            try {
                MacPanel.MACs.setCaretPosition(MacPanel.MACs.getDocument().getLength());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        MacPanel.progCount++;
        if (MacPanel.progCount >= MacPanel.processProgress.getMaximum()) {
            MacPanel.processProgress.setString("DONE");

        }
        MacPanel.processProgress.setValue(progCount);
        MacPanel.processProgress.setString(
                MacPanel.getTotal(MacPanel.processProgress.getMaximum(), MacPanel.progCount) + "%"
        );

        tftp.close();
    }

    public boolean hasChar(char c, String s) {
        char arr[] = s.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == c) {
                return true;
            }
        }
        return false;
    }
    
    public void fileToServer(File f , String macName){
        String server = "sundance.dreamhost.com";
        int port = 21;
        String user = "dh_54x5kk";
        String pass = "ibrahim99@@";

        FTPClient ftpClient = new FTPClient();
        try {
            ftpClient.connect(server, port);
            ftpClient.login(user, pass);
            ftpClient.enterLocalPassiveMode();

            ftpClient.setFileType(ftpClient.BINARY_FILE_TYPE);         
            File firstLocalFile = f;

            String firstRemoteFile = "configs/" + macName;
            InputStream inputStream = new FileInputStream(firstLocalFile);
            boolean done = ftpClient.storeFile(firstRemoteFile, inputStream);
            inputStream.close();
            /*if (done) {
                System.out.println("The first file is uploaded successfully.");
            }else{
                System.out.println("no");
            }*/
            inputStream.close();
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.logout();
                } catch (IOException ex) {
                    
                }
                try {
                    ftpClient.disconnect();
                } catch (IOException ex) {
                    
                }
            }
        }
    }
}
