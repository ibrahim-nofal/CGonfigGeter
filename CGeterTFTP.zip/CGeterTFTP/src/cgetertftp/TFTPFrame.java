/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cgetertftp;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author root
 */
public class TFTPFrame extends JFrame {

    JFrame thatFrame = null;
    JPanel mainPanel = new JPanel();
    MacPanel macPanel = new MacPanel();

    TFTPFrame() {
        super("Config Geter");
       
        Image icon = Toolkit.getDefaultToolkit().getImage("appicon.png");
        this.setIconImage(icon);
        this.setSize(640, 560);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocation(300, 50);
        macPanel = new MacPanel();
        this.getContentPane().add(macPanel, BorderLayout.CENTER);
    }

    public static void main(String arga[]) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                new TFTPFrame().show();
            }

        }).start();

    }

}
