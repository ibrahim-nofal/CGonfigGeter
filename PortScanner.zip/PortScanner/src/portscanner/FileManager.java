/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portscanner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author root
 */
public class FileManager {
    
    static PortChecker pc = new PortChecker(0);
    public static BufferedReader myReader(File in) throws IOException{
        FileInputStream fis = new FileInputStream(in);
        InputStreamReader reader = new InputStreamReader(fis);
        fis.getChannel().position(0);
        return new BufferedReader(reader);     
    }
    
    public static int lineCounter(File in) throws IOException{
        int count = 0;
        BufferedReader reader = FileManager.myReader(in);
        while(reader.readLine() != null){
            count++;
        }
        return count;
    }
    
    public static void convertRangesToIp(File in) throws IOException{
        File allRanges = new File("ranges" + PortScanner.ds + "all-ranges.txt");
        FileOutputStream fos = new FileOutputStream(allRanges);
        FileChannel fc = fos.getChannel();
        BufferedReader br = myReader(in);
        String temp = "";
        while((temp = br.readLine()) != null){
            String r1 = temp.split("-")[0];
            String r2 = temp.split("-")[1];
            ByteBuffer buffer = pc.ipRange(r1 , r2);        
            fc.write(buffer);           
        }    
        removeRepetedLine(allRanges);
    }
    
    public static void removeRepetedLine(File in){
        try {
            BufferedReader buffer = myReader(in);
            Set<String> set = new HashSet<String>(lineCounter(in));
            String temp = "";
            while((temp = buffer.readLine()) != null){
                set.add(temp);
            }
            buffer.close();
            BufferedWriter writer = new BufferedWriter(new FileWriter(in));
            for(String s : set){
                writer.write(s);
                writer.newLine();
            }
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
}
