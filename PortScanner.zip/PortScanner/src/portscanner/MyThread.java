/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portscanner;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class MyThread extends Thread {

    private String ip = "";
    private String port = "";
    private PortChecker portChecker = null;

    public MyThread(
            String ip,
            String port,
            PortChecker portChecker) {
        this.ip = ip;
        this.port = port;
        this.portChecker = portChecker;
    }
    @Override
    public void run() {

        String s = ip + ":" + port + "\n";
        try {
            FileOutputStream out = new FileOutputStream("result" + PortScanner.ds + "ip:port.txt", true);
            if (portChecker.isReachable(ip, Integer.parseInt(port))) {
                out.write(s.getBytes());
                PortScanner.result.append(s);
                PortScanner.result.setCaretPosition(PortScanner.result.getDocument().getLength());
                try {
                    PortScanner.ip_port.write(s.getBytes());
                } catch (IOException ex) {
                    Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                PortScanner.process.append(s);
                PortScanner.process.setCaretPosition(PortScanner.process.getDocument().getLength());
            }
        } catch (IOException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        PortScanner.pB.setValue(PortScanner.pB.getValue() + 1);
    }
}
