/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portscanner;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class PortChecker {

    int timeOut;
    public PortChecker(int timeOut){
        this.timeOut = timeOut;
    }
    public boolean isReachable(String ipAddress, int port) {
        Socket socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(ipAddress, port), timeOut);
            return true;
        } catch (IOException ex) {
            return false;
        } finally {
            try {
                socket.close();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void ports() {
        File out = new File("result" + PortScanner.ds + "ports.txt");
        FileWriter writer = null;
        try {
            writer = new FileWriter(out);
            BufferedWriter bw = new BufferedWriter(writer);
            int i = 0;
            while (i <= 65535) {
                bw.write(i + "\n");
                i++;
            }
            bw.close();
            writer.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

        public ByteBuffer ipRange(String from, String to) {
        File rangePorts = new File("ranges" + PortScanner.ds + "range.txt");     
        String rangesFrom[] = from.split("\\.");
        String rangesTo[] = to.split("\\.");
        int r1 = Integer.parseInt(rangesFrom[0]),
                r2 = Integer.parseInt(rangesFrom[1]),
                r3 = Integer.parseInt(rangesFrom[2]),
                r4 = Integer.parseInt(rangesFrom[3]);

        FileWriter writer = null;
        try {
            String temp = "";
            writer = new FileWriter(rangePorts);
            for (int i = 0 ; i <= 255; i++) {

                if (r1 < Integer.parseInt(rangesTo[0])) {
                    for (int j = r1; j <= Integer.parseInt(rangesTo[0]); j++) {
                        temp = j + "." + r2 + "." + r3 + "." + r4 + "\n";
                        writer.write(temp);
                    }
                    r1++;
                }
                if (r2 < Integer.parseInt(rangesTo[1])) {
                    for (int j = r2; j <= Integer.parseInt(rangesTo[1]); j++) {
                        temp = r1 + "." + j + "." + r3 + "." + r4 + "\n";
                        writer.write(temp);

                    }
                    r2++;
                }
                if (r3 < Integer.parseInt(rangesTo[2])) {
                    for (int j = r3; j <= Integer.parseInt(rangesTo[2]); j++) {
                        temp = r1 + "." + r2 + "." + j + "." + r4 + "\n";
                        writer.write(temp);

                    }
                    r3++;
                }
                if (r4 < Integer.parseInt(rangesTo[3])) {
                    for (int j = r4; j <= Integer.parseInt(rangesTo[3]); j++) {
                        temp = r1 + "." + r2 + "." + r3 + "." + j + "\n";
                        writer.write(temp);

                    }
                    r4++;
                }
            }
            RandomAccessFile fis = new RandomAccessFile(rangePorts , "r");
            FileChannel fc = fis.getChannel();
            ByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fis.length());
            return bb;
        } catch (IOException ex) {
            Logger.getLogger(PortChecker.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (writer != null) try {
                writer.close();
            } catch (IOException ex) {
                Logger.getLogger(PortChecker.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }

}
