/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portscanner;

/**
 *
 * @author root
 */
import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.ScrollPaneConstants;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JCheckBox;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PortScanner extends JFrame {

    //compnents
    ExecutorService executor;
    JButton loadIP = new JButton("Load: ip/Ranges");
    JButton scan = new JButton("Scan");
    JTextArea ips = new JTextArea(15, 15);
    static JTextArea result = new JTextArea(15, 20);
    static JTextArea process = new JTextArea(10, 10);
    JCheckBox rangePattern = new JCheckBox("Range Pattern");
    JTextField rangeFrom = new JTextField("0.0.0.0");
    JTextField rangeTo = new JTextField("255.255.255.255");
    static JProgressBar pB = new JProgressBar();
    JTextField threads = new JTextField("500");
    JTextField timeOut = new JTextField("1000");
    //program component
    PortChecker portChecker = null;
    static OutputStream ip_port = null;
    File chooserIp = null;
    static String tempIp = "";
    static String tempPort = "";
    static int stopApp = 0;
    static public String ds = "\\";
    int lineNumber = 0;
    int sleep = 0;
    int progress = 0;

    public PortScanner() {

        super("PortScanner");
        this.setLayout(null);
        this.setSize(630, 700);
        this.setResizable(false);

        pB.setBounds(310, 290, 250, 10);
        pB.setForeground(new Color(24,93,19));

        this.add(pB);

        loadIP.setBounds(290, 90, 170, 30);
        this.add(loadIP);

        JLabel threadLabel = new JLabel("Threads");
        threadLabel.setBounds(290, 140, 60, 20);
        threads.setBounds(370, 140, 60, 20);

        JLabel timeLabel = new JLabel("Time out");
        JLabel timeType = new JLabel("ms");
        timeLabel.setBounds(290, 170, 100, 20);
        timeType.setBounds(435, 170, 20, 20);
        timeOut.setBounds(370, 170, 60, 20);

        this.add(timeType);
        this.add(timeLabel);
        this.add(threadLabel);
        this.add(threads);
        this.add(timeOut);

        rangePattern.setBounds(290, 50, 130, 30);
        this.add(rangePattern);

        JLabel rangeF = new JLabel("From");
        rangeF.setBounds(290, 20, 40, 30);
        rangeFrom.setBounds(330, 20, 120, 30);
        this.add(rangeF);

        JLabel rangeT = new JLabel("To");
        rangeT.setBounds(470, 20, 20, 30);
        rangeTo.setBounds(490, 20, 120, 30);
        this.add(rangeT);
        this.add(rangeFrom);
        this.add(rangeTo);

        JScrollPane ipsPane = new JScrollPane(ips);
        ipsPane.setBounds(20, 20, 250, 300);
        this.add(ipsPane);

        JScrollPane processPane = new JScrollPane(process);
        processPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        processPane.setBounds(20, 340, 250, 300);
        this.add(processPane);

        JLabel l = new JLabel("=>");
        l.setBounds(280, 450, 30, 30);
        JScrollPane resultPane = new JScrollPane(result);
        resultPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        resultPane.setBounds(310, 340, 250, 300);
        this.add(resultPane);
        this.add(l);

        scan.setBounds(390, 220, 100, 30);
        scan.setBackground(new Color(98, 212, 78));
        scan.setForeground(Color.white);
        this.add(scan);

        loadIP.addActionListener((ActionEvent e) -> {
            loadIp();
        });
        scan.addActionListener((ActionEvent e) -> {
            new Thread() {
                @Override
                public void run() {
                    portChecker = new PortChecker(Integer.parseInt(timeOut.getText()));
                    pB.setValue(0);
                    sleep = Integer.parseInt(timeOut.getText());
                    executor = Executors.newFixedThreadPool(Integer.parseInt(threads.getText()));
                    scan();
                    executor.shutdown();
                }

            }.start();

        });

        this.setLocation(350, 0);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void scan() {

        if (rangePattern.isSelected()) {
            if (chooserIp != null) {
                try {
                    FileManager.convertRangesToIp(chooserIp);
                    lineNumber = FileManager.lineCounter(new File("ranges" + ds + "all-ranges.txt"));
                } catch (IOException ex) {
                    Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                File f = new File("ranges" + ds + "range.txt");
                portChecker.ipRange(rangeFrom.getText(), rangeTo.getText());
                try {
                    lineNumber = FileManager.lineCounter(f);
                } catch (IOException ex) {
                    Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    BufferedReader ipsRange = FileManager.myReader(f);
                    String s = "";
                    while ((s = ipsRange.readLine()) != null) {
                        ips.append(s + "\n");
                    }  
                } catch (IOException ex) {
                    Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (!new File("result" + ds + "ports.txt").exists()) {
                    portChecker.ports();
                }
            }

        } else {
            if (!new File("result" + ds + "ports.txt").exists()) {
                portChecker.ports();
            }         
        }
        try {
                lineNumber *=
                         FileManager.lineCounter(new File("result" + ds + "ports.txt"));
            } catch (IOException ex) {
                Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
            }
        pB.setMaximum(lineNumber);
        try {
            ip_port = new FileOutputStream("result" + ds + "ip:port.txt");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            BufferedReader ipReader = null;
            if (rangePattern.isSelected()) {
                if (chooserIp != null) {
                    ipReader = FileManager.myReader(new File("ranges" + ds + "all-ranges.txt"));
                } else {
                    ipReader = FileManager.myReader(new File("ranges" + ds + "range.txt"));
                }
            } else {
                ipReader = FileManager.myReader(chooserIp);
            }
            while ((tempIp = ipReader.readLine()) != null) {
                if (Thread.activeCount() > Integer.parseInt(threads.getText())) {
                    System.out.println("wait...");
                    Thread.sleep(10L);
                }
                BufferedReader brPort = FileManager.myReader(new File("result" + ds + "ports.txt"));
                while ((tempPort = brPort.readLine()) != null) {

                    MyThread t = new MyThread(tempIp, tempPort, portChecker);
                    executor.execute(t);
                }
            }
        } catch (IOException ex) {
            File ports = new File("result" + ds + "ports.txt");
            portChecker.ports();
            JOptionPane.showMessageDialog(new JOptionPane(), "Ports File not Exists!");
        } catch (InterruptedException ex) {
            Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void loadIp() {

        FileDialog dialog = new FileDialog((Frame) null, "Choose ips File");
        dialog.setMode(0);
        dialog.setVisible(true);
        final String file = dialog.getDirectory() + dialog.getFile();
        chooserIp = new File(file);
        BufferedReader bReader = null;
        try {
            this.ips.removeAll();
            bReader = new BufferedReader(new FileReader(file));
            String s = "";
            while ((s = bReader.readLine()) != null) {
                this.ips.append(s + "\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (bReader != null) try {
                bReader.close();
            } catch (IOException ex) {
                Logger.getLogger(PortScanner.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String[] args) {
        final PortScanner me = new PortScanner();

        SwingUtilities.invokeLater(
                new Runnable() {
            @Override
            public void run() {
                me.show();
            }
        }
        );
    }

}
